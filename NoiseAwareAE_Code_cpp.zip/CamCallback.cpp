/***********************************************************
* @PROJECT : Noise Aware Image Assessment metric based Auto Exposure Control
* @TITLE   : Camera CallBack Class
* @AUTHOR  : Uk Cheol Shin, KAIST RCV LAB
* @DATE    : 2018-08-14
* @BRIEF   : Calculate Entropy weighted gradient value
* @UPDATE  : 2019-01-23
* @BRIEF   : Update Control Part to use Nelder-Mead Algorithm.
***********************************************************/

#include "CamCallback.h"

// @brief Contructor
CallBackExposureValue::CallBackExposureValue(INodeMap & nodeMap) : nodeMap_(nodeMap), callbackGain_(0), callbackExposureTime_(0)
{
        int result = 0;
        result = ConfigureCallbacks(nodeMap_, callbackExposureTime_, callbackGain_);
        if(result != 0) throw -1;
}

// @brief Destoryer
CallBackExposureValue::~CallBackExposureValue()
{
        int result = 0;
        result = ResetCallbacks(nodeMap_, callbackExposureTime_, callbackGain_);
        if(result != 0) throw -1;
}

// @brief Exposure Time Update Call back function
void OnExposureTimeNodeUpdate(INode* node)
{
        CFloatPtr ptrExposureTime = node;
#if DEBUG_CALL_BACK 
        cout << "Exposure Time callback message:" << endl;
        cout << "\tLook! Exposure Time changed to " << ptrExposureTime->GetValue() << "..." << endl << endl;
#endif
        FlagExpT_ = 1;
}

// @brief Gain Update Call back function
void OnGainNodeUpdate(INode* node)
{
        CFloatPtr ptrGain = node;
#if DEBUG_CALL_BACK 
        cout << "Gain callback message:" << endl;
        cout << "\tLook now!  Gain changed to " << ptrGain->GetValue() << "..." << endl << endl;
#endif
        FlagGain_ = 1;
}

// @brief configure Callbacks
// Disable automatic Gain & Exposure
// Create the callbacks, and registering them to their respective nodes.
int CallBackExposureValue::ConfigureCallbacks(const INodeMap & nodeMap, int64_t & callbackExposureTime, int64_t & callbackGain)
{
        int result = 0;

        cout << endl << endl << "*** CONFIGURING CALLBACKS ***" << endl << endl;

        try
        {

                // 1. Trun off Auto Exposure Control realted function.
                // 1-1. Turn off automatic gain
                CEnumerationPtr ptrGainAuto = nodeMap.GetNode("GainAuto");
                if (!IsAvailable(ptrGainAuto) || !IsWritable(ptrGainAuto))
                {
                        cout << "Unable to disable automatic gain (node retrieval). Aborting..." << endl << endl;
                        return -1;
                }
                CEnumEntryPtr ptrGainAutoOff = ptrGainAuto->GetEntryByName("Off");
                if (!IsAvailable(ptrGainAutoOff) && !IsReadable(ptrGainAutoOff))
                {
                        cout << "Unable to disable automatic gain (enum entry retrieval). Aborting..." << endl << endl;
                        return -1; 
                }
                ptrGainAuto->SetIntValue(ptrGainAutoOff->GetValue());
                cout << "Automatic gain disabled..." << endl;


                // 1-2. Turn off automatic Exposure Time
                CEnumerationPtr ptrExpAuto = nodeMap.GetNode("ExposureAuto");
                if (!IsAvailable(ptrExpAuto) || !IsWritable(ptrExpAuto))
                {
                        cout << "Unable to disable automatic Exposure Time (node retrieval). Aborting..." << endl << endl;
                        return -1;
                }
                CEnumEntryPtr ptrExpAutoOff = ptrExpAuto->GetEntryByName("Off");
                if (!IsAvailable(ptrExpAutoOff) && !IsReadable(ptrExpAutoOff))
                {
                        cout << "Unable to disable automatic Exposure Time (enum entry retrieval). Aborting..." << endl << endl;
                        return -1; 
                }
                ptrExpAuto->SetIntValue(ptrExpAutoOff->GetValue());
                cout << "Automatic Exposure Time disabled..." << endl;


                // 1-3. Turn off White Balance
/*
                CEnumerationPtr ptrBalanceWhiteAuto = nodeMap.GetNode("BalanceWhiteAuto");
                if (!IsAvailable(ptrBalanceWhiteAuto) || !IsWritable(ptrBalanceWhiteAuto))
                {
                        cout << "Unable to disable automatic White Balance (node retrieval). Aborting..." << endl << endl;
                        return -1;
                }
                CEnumEntryPtr ptrBalanceWhiteAutoOff = ptrBalanceWhiteAuto->GetEntryByName("Off");
                if (!IsAvailable(ptrBalanceWhiteAutoOff) && !IsReadable(ptrBalanceWhiteAutoOff))
                {
                        cout << "Unable to disable automatic White Balance  (enum entry retrieval). Aborting..." << endl << endl;
                        return -1; 
                }
                ptrBalanceWhiteAuto->SetIntValue(ptrBalanceWhiteAutoOff->GetValue());
                cout << "Automatic White Balance disabled..." << endl;
*/


                // 2. Register callback to gain & exposure time node
                // 2-1. Register callback to Exposure Time node
                CFloatPtr ptrExpTime = nodeMap.GetNode("ExposureTime");
                if (!IsAvailable(ptrExpTime) || !IsWritable(ptrExpTime))
                {
                        cout << "Unable to retrieve Exposure Time. Aborting..." << endl << endl;
                        return -1;
                }               
                cout << "Exposure Time ready..." << endl;
                callbackExposureTime = Register(ptrExpTime, &OnExposureTimeNodeUpdate);
                cout << "Exposure Time callback registered..." << endl;

                // 2-2. Register callback to gain node
                CFloatPtr ptrGain = nodeMap.GetNode("Gain");
                if (!IsAvailable(ptrGain) || !IsWritable(ptrGain))
                {
                        cout << "Unable to retrieve gain. Aborting..." << endl << endl;
                        return -1;
                }            
                cout << "Gain ready..." << endl;
                callbackGain = Register(ptrGain, &OnGainNodeUpdate);                
                cout << "Gain callback registered..." << endl << endl;
        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                result = -1;
        }

        return result;
}


// @brief Change Exposure Time & Gain
// This function demonstrates the triggering of the nodemap callbacks. 
int CallBackExposureValue::ChangeGainAndExpTime(double gainToSet, double exptimeToSet)
{
        int result = 0;

#if DEBUG_CALL_BACK 
        cout << endl << "*** CHANGE HEIGHT & GAIN ***" << endl << endl;
#endif
        try
        {
                // 1. Change gain to trigger gain callback
                CFloatPtr ptrGain = nodeMap_.GetNode("Gain");
                if (!IsAvailable(ptrGain) || !IsWritable(ptrGain) || ptrGain->GetMax() == 0)
                {
                        cout << "Unable to retrieve gain..." << endl;
                        return -1;
                }
                
                //double gainToSet = ptrGain->GetMax() / 2.0;
#if DEBUG_CALL_BACK 
                cout << "Regular function message:" << endl;
                cout << "\tGain about to be changed to " << gainToSet << "..." << endl << endl;
#endif
                ptrGain->SetValue(gainToSet);

                // 2. Change Exposure Time to trigger Exposure Time callback
                CFloatPtr ptrExpTime = nodeMap_.GetNode("ExposureTime");
                if (!IsAvailable(ptrExpTime) || !IsWritable(ptrExpTime) || ptrExpTime->GetMax() == 0)
                {
                        cout << "Unable to retrieve Exposure Time..." << endl;
                        return -1;
                }
                
                //double exptimeToSet = ptrExpTime->GetMax() / 2.0;
#if DEBUG_CALL_BACK 
                cout << "Regular function message:" << endl;
                cout << "\tExposureTime about to be changed to " << exptimeToSet << "..." << endl << endl;
#endif
                ptrExpTime->SetValue(exptimeToSet);
        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                result = -1;
        }

        return result;
}

// @brief Change Exposure Time & Gain
// This function demonstrates the triggering of the nodemap callbacks. 
int CallBackExposureValue::ChangeGainAndExpTime()
{
        int result = 0;

        cout << endl << "*** CHANGE HEIGHT & GAIN ***" << endl << endl;

        try
        {
                // 1. Change gain to trigger gain callback
                CFloatPtr ptrGain = nodeMap_.GetNode("Gain");
                if (!IsAvailable(ptrGain) || !IsWritable(ptrGain) || ptrGain->GetMax() == 0)
                {
                        cout << "Unable to retrieve gain..." << endl;
                        return -1;
                }
                
                double gainToSet = ptrGain->GetMax() / 2.0;
                cout << "Regular function message:" << endl;
                cout << "\tGain about to be changed to " << gainToSet << "..." << endl << endl;
                ptrGain->SetValue(gainToSet);

                // 2. Change Exposure Time to trigger Exposure Time callback
                CFloatPtr ptrExpTime = nodeMap_.GetNode("ExposureTime");
                if (!IsAvailable(ptrExpTime) || !IsWritable(ptrExpTime) || ptrExpTime->GetMax() == 0)
                {
                        cout << "Unable to retrieve Exposure Time..." << endl;
                        return -1;
                }
                
                double exptimeToSet = ptrExpTime->GetMax() / 2.0;
                cout << "Regular function message:" << endl;
                cout << "\tExposureTime about to be changed to " << exptimeToSet << "..." << endl << endl;
                ptrExpTime->SetValue(exptimeToSet);
        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                result = -1;
        }

        return result;
}

// @brieft Deregistering the callbacks and thuring automatic gain, exposure time, and white balance back on.
int CallBackExposureValue::ResetCallbacks(const INodeMap & nodeMap, int64_t & callbackExposureTime, int64_t & callbackGain)
{
        int result = 0;

        try
        {
                // 1. Deregister callbacks
                Deregister(callbackExposureTime);              
                Deregister(callbackGain);
                cout << "Callbacks deregistered..." << endl;


                // 2-1. Turn automatic gain back on
                CEnumerationPtr ptrGainAuto = nodeMap.GetNode("GainAuto");
                if (!IsAvailable(ptrGainAuto) || !IsWritable(ptrGainAuto))
                {
                        cout << "Unable to enable automatic gain (node retrieval). Non-fatal error..." << endl << endl;
                        return -1;
                }
                CEnumEntryPtr ptrGainAutoContinuous = ptrGainAuto->GetEntryByName("Continuous");
                if (!IsAvailable(ptrGainAutoContinuous) && !IsReadable(ptrGainAutoContinuous))
                {
                        cout << "Unable to enable automatic gain (enum entry retrieval). Non-fatal error..." << endl << endl;
                        return -1;
                }
                ptrGainAuto->SetIntValue(ptrGainAutoContinuous->GetValue());
                cout << "Automatic gain enabled..." << endl << endl;


                // 2-2. Turn on automatic Exposure Time
                CEnumerationPtr ptrExpAuto = nodeMap.GetNode("ExposureAuto");
                if (!IsAvailable(ptrExpAuto) || !IsWritable(ptrExpAuto))
                {
                        cout << "Unable to enable automatic Exposure Time (node retrieval). Aborting..." << endl << endl;
                        return -1;
                }
                CEnumEntryPtr ptrExpAutoContinuous = ptrExpAuto->GetEntryByName("Continuous");
                if (!IsAvailable(ptrExpAutoContinuous) && !IsReadable(ptrExpAutoContinuous))
                {
                        cout << "Unable to enable automatic Exposure Time (enum entry retrieval). Aborting..." << endl << endl;
                        return -1; 
                }
                ptrExpAuto->SetIntValue(ptrExpAutoContinuous->GetValue());
                cout << "Automatic Exposure Time enabled..." << endl;


                // 2-3. Turn on White Balance
                CEnumerationPtr ptrBalanceWhiteAuto = nodeMap.GetNode("BalanceWhiteAuto");
                if (!IsAvailable(ptrBalanceWhiteAuto) || !IsWritable(ptrBalanceWhiteAuto))
                {
                        cout << "Unable to enable automatic White Balance (node retrieval). Aborting..." << endl << endl;
                        return -1;
                }
                CEnumEntryPtr ptrBalanceWhiteAutoContinuous = ptrBalanceWhiteAuto->GetEntryByName("Continuous");
                if (!IsAvailable(ptrBalanceWhiteAutoContinuous) && !IsReadable(ptrBalanceWhiteAutoContinuous))
                {
                        cout << "Unable to enable automatic White Balance  (enum entry retrieval). Aborting..." << endl << endl;
                        return -1; 
                }
                ptrBalanceWhiteAuto->SetIntValue(ptrBalanceWhiteAutoContinuous->GetValue());
                cout << "Automatic White Balance enabled..." << endl;

        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                result = -1;
        }

        return result;
}
