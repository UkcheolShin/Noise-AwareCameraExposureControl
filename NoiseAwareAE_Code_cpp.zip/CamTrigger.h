/***********************************************************
* @PROJECT : Noise Aware Image Assessment metric based Auto Exposure Control
* @TITLE   : Camera Trigger Configuration Class
* @AUTHOR  : Uk Cheol Shin, KAIST RCV LAB
* @DATE    : 2018-08-14
* @BRIEF   : Configure Camera Trigger option to use software trigger controlled by gain&exposure callback
* @UPDATE  : 2019-01-23
* @BRIEF   : Update Control Part to use Nelder-Mead Algorithm.
***********************************************************/
#ifndef __CAM_TRIGGER_H__
#define __CAM_TRIGGER_H__

#include "Spinnaker.h"
#include "SpinGenApi/SpinnakerGenApi.h"
#include "SharedVariable.h"

#include <iostream>
#include <sstream>
#include <chrono>

using namespace Spinnaker;
using namespace Spinnaker::GenApi;
using namespace Spinnaker::GenICam;
using namespace std;

class Trigger
{
private :
        CameraPtr pCam_;

        // @brief trigger type
        // software trigger / hardware trigger
        enum triggerType
        {
                SOFTWARE,
                HARDWARE
        };
        const triggerType chosenTrigger;
        // @brief configure the camera to use a trigger
        int ConfigureTrigger(CameraPtr pCam);
        // @brief Return the camera to a normal state by turning off trigger mode
        int ResetTrigger(CameraPtr pCam);
public :
        Trigger(CameraPtr pCam);
        ~Trigger();
        // @brief Retrieves a single image using the trigger.
        int GrabNextImageByTrigger(ImagePtr & pResultImage);
};

#endif // define __CAM_TRIGGER_H__