/***********************************************************
* @PROJECT : Noise Aware Image Assessment metric based Auto Exposure Control
* @TITLE   : Camera Class
* @AUTHOR  : Uk Cheol Shin, KAIST RCV LAB
* @DATE    : 2019-01-23
* @BRIEF   : Camera Class
* @UPDATE  : -
* @BRIEF   : -
***********************************************************/

#include "CamExposureControl.h"


// This function acts as the body of the example; please see NodeMapInfo example 
// for more in-depth comments on setting up cameras.
CAMERA::CAMERA(CameraPtr pCam, CameraPtr pAECam, double InitGain, double InitExpT) : pCam_(pCam), pAECam_(pAECam), status(0)
{
        try
        {
                // Initialize camera
                cout << "1. Cam init ...." ;
                pCam_->Init();

                status += PrintDeviceInfo(pCam_);    // Print device info

                cout << "2. Configuration init ...." ;

                pCamTrigger_ = new Trigger(pCam_);                // Configure trigger
                cout << "2-1. Camera Trigger mode enable..." << endl;

                INodeMap & nodeMap = pCam_->GetNodeMap();                // Retrieve GenICam nodemap
                pCamCallback_ = new CallBackExposureValue(nodeMap);                // Configure callbacks
                cout << "2-2. Camera Callback mode enable..." << endl;

                // Configure chunk data
                //pCamChunk_ = new CamChunkData(nodeMap);
                //cout << "2-3. Camera ChunkData mode enable..." << endl;

                // Set acquisition mode to continuous
                if (pCam_->AcquisitionMode == NULL || pCam_->AcquisitionMode.GetAccessMode() != RW)
                {
                        cout << "Unable to set acquisition mode to continuous. Aborting..." << endl << endl;
                        status += -1;
                }
                pCam_->AcquisitionMode.SetValue(AcquisitionMode_Continuous);
                cout << "2-2. Acquisition mode set to continuous..." << endl;
              
	            // Set Pixel mode to RGB8
                if (pCam_->PixelFormat == NULL || pCam_->PixelFormat.GetAccessMode() != RW)
                {
                        cout << "Unable to set PixelFormat to RGB8. Aborting..." << endl << endl;
                        status += -1;
                }
                pCam_->PixelFormat.SetValue(PixelFormat_RGB8);
                cout << "2-3. PixelFormat mode set to RGB8..." << endl << endl;;

                // Begin acquiring images
                pCam_->BeginAcquisition();
                cout << "3. Start Image Acquision ..." << endl << endl;;

                // Drop the initial image
                ImagePtr pResultImage = NULL;
                
                pCamCallback_->ChangeGainAndExpTime(InitGain,InitExpT);
                usleep(300);        
                cout << "3-1. Wait ..." << endl << endl;;
                status = status | pCamTrigger_->GrabNextImageByTrigger(pResultImage);
                
                //pResultImage = pCam_->GetNextImage();
                //pCam_->TriggerSoftware.Execute();

                cout << "3-1. Wait ..." << endl << endl;;
                pCamCallback_->ChangeGainAndExpTime(InitGain,InitExpT);
                usleep(100);        
                status = status | pCamTrigger_->GrabNextImageByTrigger(pResultImage);

                cout << "4. Image Acquision Test ..." << endl << endl;;

                // Controler init
                pImgQualFunc_ = new IMAGE_QUALITY_ESTIMATOR();
                pNMOpt = new Nelder_Mead_Opt();

                cout << "5. Noise-Aware Exposure Control Start ..." << endl << endl;;
                
        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                status = -1;
        }
}

CAMERA::~CAMERA()
{
                // End acquisition
                pCam_->EndAcquisition();
                cout << "1. Stop Image Acquision ..." << endl << endl;;
                // Reset callbacks
                delete pCamCallback_;
                delete pCamTrigger_;
                //delete pCamChunk_;
                delete pImgQualFunc_;
                // Deinitialize camera
                pCam_->DeInit();
                cout << "4. Stop Camera ..." << endl << endl;;
}


// This function prints the device information of the camera from the transport
// layer; please see NodeMapInfo example for more in-depth comments on printing
// device information from the nodemap.
int CAMERA::PrintDeviceInfo(CameraPtr pCam)
{
        int result = 0;
        cout << endl << "*** DEVICE INFORMATION ***" << endl << endl;
        try
        {
                INodeMap & nodeMap = pCam->GetTLDeviceNodeMap();
                FeatureList_t features;
                CCategoryPtr category = nodeMap.GetNode("DeviceInformation");
                if (IsAvailable(category) && IsReadable(category))
                {
                        category->GetFeatures(features);
                        FeatureList_t::const_iterator it;
                        for (it = features.begin(); it != features.end(); ++it)
                        {
                                CNodePtr pfeatureNode = *it;
                                cout << pfeatureNode->GetName() << " : ";
                                CValuePtr pValue = (CValuePtr)pfeatureNode;
                                cout << (IsReadable(pValue) ? pValue->ToString() : "Node not readable");
                                cout << endl;
                        }
                }
                else
                {
                        cout << "Device control information not available." << endl;
                }
        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                result = -1;
        }
        return result;
}


// Saving image and return its results on cam 1
int CAMERA::SaveImages(CameraPtr pCam, ImagePtr pResultImage, double exposureTimeToSet, double gainToSet)
{
        int result = 0;
        static int count = 0;
        //cout << endl << "*** IMAGE ACQUISITION ***" << endl << endl;
        try
        {
                // Convert image to mono 8
                ImagePtr convertedImage = pResultImage->Convert(PixelFormat_RGB8);

                // Create a unique filename
                ostringstream filename;
                filename << "CapturedImg-";
                filename << count++ <<"-ExpT-" << exposureTimeToSet << "-ISO-" << gainToSet << ".jpg";

                // Save image
                convertedImage->Save(filename.str().c_str());
                //cout << "Image saved at " << filename.str() << endl;
                //cout << endl;   
        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                result = -1;
        }
        return result;
}


// Saving image and return its results on cam2 running AE algorithm
int AESaveImages(CameraPtr pCam, ImagePtr pResultImage, double exposureTimeToSet, double gainToSet)
{
        int result = 0;
        static int count = 0;
        //cout << endl << "*** IMAGE ACQUISITION ***" << endl << endl;
        try
        {
                // Convert image to mono 8
                ImagePtr convertedImage = pResultImage->Convert(PixelFormat_RGB8);

                // Create a unique filename
                ostringstream filename;
                filename << "AE_CapturedImg-";
                filename << count++ <<"-ExpT-" << exposureTimeToSet << "-ISO-" << gainToSet << ".jpg";

                // Save image
                convertedImage->Save(filename.str().c_str());
                //cout << "Image saved at " << filename.str() << endl;
                //cout << endl;   
        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                result = -1;
        }
        return result;
}

int CAMERA::ConvertToCVMat(ImagePtr pImage, Mat& mOutput)
{
    unsigned int width = pImage->GetWidth();
    unsigned int height = pImage->GetHeight();
    unsigned int stride = pImage->GetStride();
    unsigned int bitsPerPixel = pImage->GetBitsPerPixel();
    unsigned int imageSize = pImage->GetImageSize();
    unsigned int wPadding = pImage->GetXPadding();
    unsigned int hPadding = pImage->GetYPadding();

    PixelFormatEnums ePixelFormat = pImage->GetPixelFormat();
    //cout<<ePixelFormat<<endl;
    switch(ePixelFormat){
    case PixelFormat_BayerRG16:{
        // PointGrey RG(RGGB) == OpenCV BG
        Mat rawData = Mat(height+hPadding, width+wPadding, CV_16UC1, (uint16_t*)pImage->GetData());
        mOutput = rawData.clone();
        //cvtColor(rawData, mOutput, CV_BayerBG2BGR);
        return EXIT_SUCCESS;
        break;
    }
    case PixelFormat_Mono8:{
        Mat rawData = Mat(height+hPadding, width+wPadding, CV_8UC1, (uint8_t*)pImage->GetData());
        mOutput = rawData.clone();
        return EXIT_SUCCESS;
        break;
    }
    case PixelFormat_BGR8:{
        Mat rawData = Mat(height+hPadding, width+wPadding, CV_8UC3, (uint8_t*)pImage->GetData());
        mOutput = rawData.clone();
        return EXIT_SUCCESS;
        break;
    }
    case PixelFormat_BayerRG8:{
        // PointGrey RG(RGGB) == OpenCV BG
        Mat rawData = Mat(height+hPadding, width+wPadding, CV_8UC1, (uint8_t*)pImage->GetData());
        mOutput = rawData.clone();
        cvtColor(rawData, mOutput, CV_BayerBG2BGR);
        return EXIT_SUCCESS;
        break;
    }case PixelFormat_RGB8:{
        Mat rawData = Mat(height+hPadding, width+wPadding, CV_8UC3, (uint8_t*)pImage->GetData());

        ///cvtColor(rawData,rawData,COLOR_RGB2BGR); .
        // rgb to bgr
        cv::Mat rgb[3];
        cv::split(rawData, rgb);
        cv::Mat bgr[] = {rgb[2],rgb[1],rgb[0]};
        cv::Mat rawData_bgr;
        cv::merge(bgr, 3, rawData_bgr);
        mOutput = rawData_bgr.clone();

        return EXIT_SUCCESS;
        break;
    }default:
        cout << "Mat conversion from " << pImage->GetPixelFormatName()
             << " is not supported." << endl;
        return EXIT_FAILURE;
        break;
    }
}


// @brief Wrapping GetImageAndAssessQuality for the Noise-Aware Auto Exposure Control.
// input range check and modify the value.
void CAMERA::CostFunc(point_t *point)
{
    double ExpTimeToSet = point->x[0];
    double GainToSet = point->x[1];
    int FlagSave = 1;
    static int iter_count = 0;

    //input ragne check
    if(ExpTimeToSet < 100){
        point->x[0] = ExpTimeToSet = 100.0;
    }
    else if(ExpTimeToSet >= 67000.0){
        point->x[0] = ExpTimeToSet = 67000.0;
    }

    if(GainToSet < 0.0){
        point->x[1] = GainToSet = 0.1;
    }
    else if(GainToSet >= 24.0){
        point->x[1] = GainToSet = 24.0;
    }
    
    GetImageAndAssesQuality(ExpTimeToSet, GainToSet, FlagSave, point);

    #if LOG_DEBUG
    printf("Evaluation %04d                     ", iter_count++);
    printf("[ ");
    for (int i = 0; i < 2; i++) {
        printf("%.2f ", point->x[i]);
    }
    printf("]    %.2f \n", point->fx);
    #endif
}

// @brief Get Image and Assess Image Quality
double CAMERA::GetImageAndAssesQuality(double ExpTimeToSet, double GainToSet, int FlagSave, point_t *point)
{
    try
    {
        int result = 0;
        ImagePtr pResultImage;
        float resize_factor = 0.75;
        int flag_boost = 1;

#if TIME_DEBUG
clock_t func_begin, func_end;
func_begin = clock();
#endif

        // 1. Set Exposure Time / Gain value
        result = result | pCamCallback_->ChangeGainAndExpTime(GainToSet,ExpTimeToSet);
        if(result != 0) std::cout << "set gain error!!"  << std::endl;

        // 2. Get image
        result = result | pCamTrigger_->GrabNextImageByTrigger(pResultImage);
        if(result != 0) std::cout << "trigger error!!"  << std::endl;

        pCam_->TriggerSoftware.Execute();
        pResultImage = pCam_->GetNextImage();

        pCam_->TriggerSoftware.Execute();
        pResultImage = pCam_->GetNextImage();

        pAECam_->TriggerSoftware.Execute();
        ImagePtr pAEResultImage = pAECam_->GetNextImage();

        pAECam_->TriggerSoftware.Execute();
        pAEResultImage = pAECam_->GetNextImage();

#if TIME_DEBUG
func_end = clock();
double func_time = (double)(func_end - func_begin) / CLOCKS_PER_SEC;
std::cout << " 'Image Grab' Process take : " << func_time*1000 << "msec" << std::endl;
#endif

        // Ensure image completion
        if (pResultImage->IsIncomplete())
        {
                cout << "Image incomplete with image status " << pResultImage->GetImageStatus() << "..." << endl << endl;
                return 1;
        }
        else 
        {

#if TIME_DEBUG
func_begin = clock();
#endif
            // 3. get current Gain / Exposure Time value
            double CurGain = pCam_->Gain.GetValue();
            double CurExpT = pCam_->ExposureTime.GetValue();

            double CurAEGain = pAECam_->Gain.GetValue();
            double CurAEExpT = pAECam_->ExposureTime.GetValue();

            // 4. save images
            if(FlagSave == 1){
                SaveImages(pCam_,pResultImage,CurExpT,CurGain); 
                AESaveImages(pAECam_,pAEResultImage,CurAEExpT,CurAEGain);
            }

            /*
            // 5. Display chunk data
                pCamChunk_->DisplayChunkData(pResultImage);
            */

#if TIME_DEBUG
func_end = clock();
func_time = (double)(func_end - func_begin) / CLOCKS_PER_SEC;
std::cout << " 'Image Save' Process take : " << func_time*1000 << "msec" << std::endl;
#endif

#if TIME_DEBUG
func_begin = clock();
#endif
            // 6. Disply the Image
            cv::Mat mImage;
            ConvertToCVMat(pResultImage, mImage); 

            // 7. Calculate Image Quality Value
            double ImQual = -(pImgQualFunc_->GetImgQualityValue(mImage, resize_factor, flag_boost));
            point->fx = ImQual;
            point->fx2 = (pImgQualFunc_->alpha)*pImgQualFunc_->CurGradInfo + (1-pImgQualFunc_->alpha)*pImgQualFunc_->CurEntroInfo;
            point->f_Inten = pImgQualFunc_->CurIntensity;
            point->f_Grad = pImgQualFunc_->CurGradInfo;
            point->f_Entro = pImgQualFunc_->CurEntroInfo;
            point->f_Noise = pImgQualFunc_->CurNoiseInfo;

            // 8.Release image
            pResultImage->Release();

#if TIME_DEBUG
func_end = clock();
func_time = (double)(func_end - func_begin) / CLOCKS_PER_SEC;
std::cout << " 'Calculate Image Quality' Process take : " << func_time*1000 << "msec" << std::endl;
#endif
            return ImQual;
        }
    }
    catch (Spinnaker::Exception &e)
    {
            cout << "Error: " << e.what() << endl;
            return 1;
    }
}

// @brief Auto Exposure Control using NM-algorihtm & Noise-Aware Image Quality Assessment metric
int CAMERA::NelderMeadControl(const point_t *start, point_t *solution, const optimset_t *optimset)
{
    int n = 2;

    // internal points, respectively, reflection, expansion, contraction point
    point_t point_r;
    point_t point_e;
    point_t point_c;
    point_t centroid;
    point_t point_test;

    // allocate memory for internal points
    point_r.x = (double*) malloc(n * sizeof(double));
    point_e.x = (double*) malloc(n * sizeof(double));
    point_c.x = (double*) malloc(n * sizeof(double));
    centroid.x = (double*) malloc(n * sizeof(double));
    point_test.x = (double*) malloc(n * sizeof(double));

    int iter_count = 0;
    int eval_count = 0;
    int flag_NM = 0;
    float Coeff = 2.0;
    float alpha = 1.5;

    // initial simplex has size n + 1 where n is the dimensionality pf the data
    // Make initial anchor according to current 
    simplex_t simplex;
    simplex.n = n;
    simplex.p = (point_t *) malloc((n + 1) * sizeof(point_t));
    simplex.p_avg = (point_t *) malloc((n + 1) * sizeof(point_t));
    simplex.p_avg->x = (double *) malloc(n * sizeof(double));

    for (int i = 0; i < n + 1; i++) {
	simplex.p[i].x = (double *) malloc(n * sizeof(double));
    	for (int j = 0; j < n; j++) {
      		simplex.p[i].x[j] =
          	(i - 1 == j) ? (start->x[j] != 0.0 ? Coeff * start->x[j] : 0.00025)
                             : start->x[j];
    	}
    	CostFunc(simplex.p + i);
    	if(eval_count == 0){
      		if(pImgQualFunc_->CurIntensity >= 128)
    	 		Coeff = -1 / alpha * (pImgQualFunc_->CurIntensity/255.0);
      		else 
		        Coeff = alpha * (1 - pImgQualFunc_->CurIntensity/255.0);
            //if(pImgQualFunc_->CurNoiseInfo > 1.0) Coeff *= 1.3;
    	} 
       	eval_count++;
    }

    pNMOpt->print_point(&simplex);
    // sort points in the simplex so that simplex.p[0] is the point having
    // minimum fx and simplex.p[n] is the one having the maximum fx
    pNMOpt->simplex_sort(&simplex);
    pNMOpt->calculate_diameter(&simplex);

    // compute the simplex centroid
    pNMOpt->get_centroid(&simplex, &centroid);
    iter_count++;

    while(1)
    {
        int flag_exception = 0;
        int flag_converge = 0;
 
        // continue minimization until stop conditions are met
        while(!flag_converge && !flag_exception)
        {
            if(!pNMOpt->continue_minimization(&simplex, eval_count, iter_count, optimset)) flag_converge = 1;

            #if TIME_DEBUG2
            clock_t func_begin, func_end;
            func_begin = clock();
            #endif

            int shrink = 0;
            
            // Refelction
            pNMOpt->update_point(&simplex, &centroid, RHO, &point_r); 
            CostFunc(&point_r);
            eval_count++;
            flag_exception = pNMOpt->Exception_Catcher(&point_r, simplex.p_avg, simplex.max_diameter, optimset);

            if(flag_exception != 0){
                std::cout << "reflection" <<std::endl;
                point_test.x[0] = point_r.x[0];
                point_test.x[1] = point_r.x[1];
                point_test.f_Inten = point_r.f_Inten;
                break;  
            } 

            // Go futher
            if (point_r.fx < simplex.p[0].fx) {
                pNMOpt->update_point(&simplex, &centroid, RHO * CHI, &point_e);
                CostFunc(&point_e);
                flag_exception = pNMOpt->Exception_Catcher(&point_e, simplex.p_avg, simplex.max_diameter, optimset);

                if(flag_exception != 0){
                    std::cout << "expand" <<std::endl;
                    point_test.x[0] = point_e.x[0];
                    point_test.x[1] = point_e.x[1];
                    point_test.f_Inten = point_e.f_Inten;
                    break;  
                } 

                eval_count++;
                if (point_e.fx < point_r.fx) {
                    pNMOpt->copy_point(n, &point_e, simplex.p + n);  flag_NM = 1; // expand
                } else {
                    pNMOpt->copy_point(n, &point_r, simplex.p + n);  flag_NM = 2; // reflect
                }
            } else {
                if (point_r.fx < simplex.p[n - 1].fx) {                    
                    pNMOpt->copy_point(n, &point_r, simplex.p + n);  flag_NM = 2; // reflect
                }else{
                    if(point_r.fx < simplex.p[n].fx) 
                    {
                        pNMOpt->update_point(&simplex, &centroid, RHO * GAMMA, &point_c);
                        CostFunc(&point_c);
                        flag_exception = pNMOpt->Exception_Catcher(&point_c, simplex.p_avg, simplex.max_diameter, optimset);

                        if(flag_exception != 0){
                            std::cout << "contract1" <<std::endl;
                            point_test.x[0] = point_c.x[0];
                            point_test.x[1] = point_c.x[1];
                            point_test.f_Inten = point_c.f_Inten;
                            break;  
                        }
                        eval_count++;
                        if(point_c.fx <= point_r.fx) {
                            pNMOpt->copy_point(n, &point_c, simplex.p + n); flag_NM = 3; // contract outside
                        } else {
                            flag_NM = 5;  shrink = 1;
                        }
                    } else {
                        pNMOpt->update_point(&simplex, &centroid, -GAMMA, &point_c);
                        CostFunc(&point_c);

                        eval_count++;
                        if (point_c.fx <= simplex.p[n].fx) {
                            pNMOpt->copy_point(n, &point_c, simplex.p + n); flag_NM = 4; // contract inside 
                        } else {
                            shrink = 1; flag_NM = 5;  // shrink
                        }
                    }
              }
            }

            if (shrink) {
              for (int i = 1; i < n + 1; i++) {
                for (int j = 0; j < n; j++) {
                  simplex.p[i].x[j] = simplex.p[0].x[j] +
                                      SIGMA * (simplex.p[i].x[j] - simplex.p[0].x[j]);
                }
                CostFunc(simplex.p + i);
                flag_exception = pNMOpt->Exception_Catcher(simplex.p + i, simplex.p_avg, simplex.max_diameter, optimset);

                if(flag_exception != 0){
                    std::cout << "shrink" <<std::endl;
                    point_test.x[0] = (simplex.p + i)->x[0];
                    point_test.x[1] = (simplex.p + i)->x[1];
                    point_test.f_Inten = (simplex.p + i)->f_Inten;                
                    break;  
                } 

                eval_count++;
              }
              pNMOpt->simplex_sort(&simplex);
            } else {
              for (int i = n - 1; i >= 0 && simplex.p[i + 1].fx < simplex.p[i].fx; i--) {
                pNMOpt->swap_points(n, simplex.p + (i + 1), simplex.p + i);
              }
            }

            pNMOpt->get_centroid(&simplex, &centroid);
            pNMOpt->calculate_diameter(&simplex);
            
            if (optimset->verbose) {
                #if LOG_DEBUG
                printf("Iteration %04d     ", iter_count);
                switch(flag_NM)
                {
                  case 1 :
                    printf("expand          ");
                  break;
                  case 2:
                    printf("reflect         ");
                  break;
                  case 3:
                    printf("contract out    ");
                  break;
                  case 4:
                    printf("contract in     ");
                  break;
                  case 5:
                    printf("shrink         ");
                  break;
                  case 6:
                    printf("Restart         ");
                  break;
                  case 7:
                    printf("Inverse Shrink  ");
                  break;
                  default:
                    printf("Error!!         ");      
                  break;
                }

                // print current minimum
                for (int j = 0; j < n+1 ; j++){
                  printf("[ ");
                  for (int i = 0; i < n; i++) {
                    printf("%.2f ", simplex.p[j].x[i]);
                  }
                  printf("]    %.2f", simplex.p[j].fx);            
                }
                printf("max_dia: %.4f", simplex.max_diameter);
                printf("\n");
                #endif
            }
            iter_count++;    

            #if TIME_DEBUG2
            func_end = clock();
            double func_time = (double)(func_end - func_begin) / CLOCKS_PER_SEC;
            std::cout << " 'NM method' Process take : " << func_time*1000 << "msec" << std::endl;
            #endif
        }

        while(flag_converge)
        {   
            std::cout << "converged" <<std::endl;
            // Keep current state
            for(int i = 0 ; i < n ; i++)
                point_test.x[i] = simplex.p_avg->x[i]; 
            CostFunc(&point_test);
            // Catch Execption
            flag_exception = pNMOpt->Exception_Catcher(&point_test, simplex.p_avg, simplex.max_diameter, optimset, flag_converge);
            if(flag_exception != 0)
            {
                flag_converge = 0;
                break;
            }
        }

        //Exeption handle 
        // 1. Sudden Change
        //  : Calculate Target EV
        //  : Do Line Search
        //  : Make Simplex
        if(flag_exception == 1) 
        {
            flag_NM = 6;
            flag_exception = 0;
            // Calculate Target EV, CurEV            
            double EV_cur = std::log2((point_test.x[0]/67000.0)*((point_test.x[1]+1)/24.0));
            double EV_target = EV_cur + log2(0.5) - log2(point_test.f_Inten); 
            
            //scale > 1 --> for same EV, big expt, small gain / scale < 1 --> for same EV, small expt, big gain
            // indoor --> scale : 2 or lower. expt = scale * gain, outdoor --> 5?
            double fx_best = point_test.fx;
            double scale = (point_test.x[0]/67000.0)/((point_test.x[1]+1)/24.0); 
            std::cout << "EV_cur: " << EV_cur << "    EV_target: " << EV_target <<"    Scale: "<< scale <<  std::endl;
                
            // 1. line search, decide initial point
            for(int i = 1; i < 5; i++)
            {
                // Save and if find the maximum, break
                if(point_test.fx <= fx_best)
                  fx_best = point_test.fx;  
                else{
                    break;
                }

                double EV_next = EV_cur + (0.25*(double)i)*(EV_target - EV_cur);
                if(scale >= 4 || scale <= 0.5) scale = 1; // if too bias to one side, re-scale
                std::cout << "EV_next" << EV_next << std::endl;

                // Decompose EV to ExpT and Gain
                double tmp_gain = sqrtf(pow(2.0, EV_next) / scale);
                point_test.x[0] = tmp_gain*scale*67000.0;  // next expt                     
                point_test.x[1] = tmp_gain*24.0 -1;  // next gain

                // Evaluate
                CostFunc(&point_test);                    
            }
 
            // 2. Calculate initial simplex
            for (int i = 0; i < n + 1; i++) {
                for (int j = 0; j < n; j++) {
                    simplex.p[i].x[j] =
                    (i - 1 == j) ? (point_test.x[j] != 0.0 ? Coeff * point_test.x[j] : 0.00025)
                                     : point_test.x[j];
                }
                if(i != 0){
                    CostFunc(simplex.p + i);
                }

                if(eval_count == 0){
                    if(simplex.p[i].f_Inten >= 0.5)
                        Coeff = -1 / alpha * (simplex.p[i].f_Inten);
                    else 
                        Coeff = alpha * (1 - simplex.p[i].f_Inten);
                } 
                eval_count++;
            }
            pNMOpt->simplex_sort(&simplex);
        }
        else if(flag_exception == 2) // 2. Inverse shirnk
        {
            // inverse shrink
            flag_NM = 7;
            flag_exception = 0;

            // 1. Calculate Scale Factor
            double L_test = point_test.f_Inten/(point_test.x[0]*(point_test.x[1]+1));
            double L_avg  = simplex.p_avg->f_Inten/(simplex.p_avg->x[0]*(simplex.p_avg->x[1]+1));
            double L_ratio = L_test/L_avg;
            if(L_ratio < 1) L_ratio = 1/L_ratio;
            if(simplex.max_diameter < 0.1*optimset->tol_Diamter) simplex.max_diameter = optimset->tol_Diamter;

            double const const_IS = 0.2;
            double SIGMA2 = const_IS * L_ratio/simplex.max_diameter;
            std::cout << "SIGMA2 : " << SIGMA2 << std::endl;
            // 2.Conduct inverse shrink            
            for (int i = 0; i < n + 1; i++) {
                for (int j = 0; j < n; j++) {
                  simplex.p[i].x[j] = simplex.p[0].x[j] + SIGMA2 * (simplex.p[i].x[j] - simplex.p[0].x[j]);
                }
                CostFunc(simplex.p + i);
                eval_count++;
            }
            pNMOpt->simplex_sort(&simplex);
        }

        pNMOpt->get_centroid(&simplex, &centroid);
        pNMOpt->calculate_diameter(&simplex);
        
        if (optimset->verbose) {
            #if LOG_DEBUG
            printf("Iteration %04d     ", iter_count);
            switch(flag_NM)
            {
              case 1 :
                printf("expand          ");
              break;
              case 2:
                printf("reflect         ");
              break;
              case 3:
                printf("contract out    ");
              break;
              case 4:
                printf("contract in     ");
              break;
              case 5:
                printf("shrink         ");
              break;
              case 6:
                printf("Restart         ");
              break;
              case 7:
                printf("Inverse Shrink  ");
              break;
              default:
                printf("Error!!         ");      
              break;
            }

            // print current minimum
            for (int j = 0; j < n+1 ; j++){
              printf("[ ");
              for (int i = 0; i < n; i++) {
                printf("%.2f ", simplex.p[j].x[i]);
              }
              printf("]    %.2f", simplex.p[j].fx);            
            }
            printf("   max_dia : %.4f", simplex.max_diameter);
            printf("\n");
            #endif
        }

        iter_count++;    

    }

    // save solution in output argument
    solution->x = (double *) malloc(n * sizeof(double));
    pNMOpt->copy_point(n, simplex.p + 0, solution);

    // free memory
    free(centroid.x);
    free(point_r.x);
    free(point_e.x);
    free(point_c.x);
    for (int i = 0; i < n + 1; i++) {
    free(simplex.p[i].x);
    }
    free(simplex.p);
    return 0;
}

void CAMERA::RunNoiseAwareExposureControl()
{
    // optimisation settings
    // we need different setting indoor / outdoor setting
    optimset_t optimset;
    optimset.tolx = 5;    // tolerance on the simplex solutions coordinates
    optimset.tolExpT = 100;    // tolerance on the simplex solutions coordinates
    optimset.tolGain = 0.5;    // tolerance on the simplex solutions coordinates
    optimset.tolf = 0.05;    // tolerance on the function value
    optimset.max_iter = 100; // maximum number of allowed iterations
    optimset.max_eval = 200; // maximum number of allowed function evaluations
    optimset.verbose = 1;     // toggle verbose output during minimization
    optimset.tol_Diamter = 0.02; // if diameter 0.01, delta_expt = 700, delta_gain = 0.24
    optimset.tol_diff = 15;

    int converge = 1;

    // initial point
    point_t start; // initial point
    start.x = (double*) malloc(2 * sizeof(double));
    start.x[0] = pCam_->ExposureTime.GetValue();
    start.x[1] = pCam_->Gain.GetValue();
    point_t solution;

    converge = NelderMeadControl(&start, &solution, &optimset);
}