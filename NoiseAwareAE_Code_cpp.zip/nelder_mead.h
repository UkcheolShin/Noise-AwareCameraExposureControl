#ifndef NELDER_MEAD_H
#define NELDER_MEAD_H

//-----------------------------------------------------------------------------
// Definitions
//-----------------------------------------------------------------------------

#define PI 3.1415926535897932384626433832795
#define EPS 0.00000000001

//#define RHO 1.0   // reflection factor
//#define CHI 2.0   // expansion factor
#define RHO 0.75   // reflection factor
#define CHI 0.75   // expansion factor

#define GAMMA 0.5 // contraction factor
#define SIGMA 0.5  // shirink factor
//#define SIGMA2 1.5  // shirink factor

#define SQUARE(x) ((x) * (x))

// define a generic point containing a position (x) and a value (fx)
typedef struct {
  double *x;
  double fx;
  double fx2;
  double f_Inten;
  double f_Grad;
  double f_Entro;
  double f_Noise;
} point_t;

// define a simplex struct containing an array of n+1 points (p)
// each having dimension (n)
typedef struct {
  point_t *p;
  point_t *p_avg;
  int n;
  double max_diameter;
  double min_diameter;
} simplex_t;

// define optimization settings
typedef struct {
  double tolExpT;   // stop criteria
  double tolGain;   // stop criteria
  double tolx;   // stop criteria
  double tolf;   // stop criteria
  double tol_Diamter; //execption handle
  double tol_diff; //execption handle
  int max_iter;  // max iteration num
  int max_eval;  // max evaluation num
  int verbose;
} optimset_t;

//-----------------------------------------------------------------------------
// Cost function interface
// objective function pointer 
//-----------------------------------------------------------------------------

typedef void (*fun_t)(int, point_t *, const void *);

#endif // NELDER_MEAD_H
