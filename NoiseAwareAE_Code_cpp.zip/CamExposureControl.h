/***********************************************************
* @PROJECT : Noise Aware Image Assessment metric based Auto Exposure Control
* @TITLE   : Camera Class
* @AUTHOR  : Uk Cheol Shin, KAIST RCV LAB
* @DATE    : 2019-01-23
* @BRIEF   : Camera Class
* @UPDATE  : -
* @BRIEF   : -
***********************************************************/
#ifndef __CAMERA_EXPOSURE_CONTROL_H__
#define __CAMERA_EXPOSURE_CONTROL_H__

// Spinaker Header
#include "Spinnaker.h"
#include "SpinGenApi/SpinnakerGenApi.h"

// OpenCV Header
#include <opencv2/core.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>

// C, C++ Header
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <stdarg.h>
#include <sstream>
#include <chrono>
#include <string>
#include <vector>
#include <unistd.h>
#include <cmath>

// User Headher
#include "nelder_mead.h"
#include "CamCallback.h"
#include "CamTrigger.h"
#include "CamChunkData.h"
#include "ImageAssessMetric.h"

#define LOG_DEBUG 1
#define TIME_DEBUG 0
#define TIME_DEBUG2 0

using namespace Spinnaker;
using namespace Spinnaker::GenApi;
using namespace Spinnaker::GenICam;
using namespace std;
using namespace cv;

class CAMERA
{
private :
	CameraPtr pCam_;
	CameraPtr pAECam_;
	Trigger * pCamTrigger_;	
	CamChunkData * pCamChunk_;
	CallBackExposureValue * pCamCallback_;
	IMAGE_QUALITY_ESTIMATOR * pImgQualFunc_;
	Nelder_Mead_Opt * pNMOpt;
	
	int status;

	// @brief Print Device Information of the camera from the transport layer
	int PrintDeviceInfo(CameraPtr pCam);

	// @brief Save the image
	int SaveImages(CameraPtr pCam, ImagePtr pResultImage, double exposureTimeToSet, double gainToSet);

	// @brief Convert Cam Image type to OpenCv Datatype.
	int ConvertToCVMat(ImagePtr pImage, Mat& mOutput);

	// @brief Get Image and Assess Image Quality
	double GetImageAndAssesQuality(double ExpTimeToSet, double GainToSet, int FlagSave, point_t *point);

	// @brief Wrapping GetImageAndAssessQuality for the Noise-Aware Auto Exposure Control.
	void CostFunc(point_t *point);

	// @brief Auto Exposure Control using NM-algorihtm & Noise-Aware Image Quality Assessment metric
	int NelderMeadControl(const point_t *start, point_t *solution, const optimset_t *optimset);

public :
	CAMERA(CameraPtr pCam, CameraPtr pAECam, double InitGain, double InitExpT);
	~CAMERA();

	void RunNoiseAwareExposureControl();
};

#endif // define __CAMERA_H__
