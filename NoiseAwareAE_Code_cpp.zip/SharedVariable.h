/***********************************************************
* @PROJECT : Noise Aware Image Assessment metric based Auto Exposure Control
* @TITLE   : Camera Class
* @AUTHOR  : Uk Cheol Shin, KAIST RCV LAB
* @DATE    : 2019-01-23
* @BRIEF   : Camera Class
* @UPDATE  : -
* @BRIEF   : -
***********************************************************/
#ifndef __SHARE_H__
#define __SHARE_H__

#include <iostream>

extern int FlagExpT_;
extern int FlagGain_;

#endif // #define __SHARE_H__