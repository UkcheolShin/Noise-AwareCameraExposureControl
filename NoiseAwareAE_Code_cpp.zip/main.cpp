/***********************************************************
* @PROJECT : Noise Aware Image Assessment metric based Auto Exposure Control
* @TITLE   : Camera Class
* @AUTHOR  : Uk Cheol Shin, KAIST RCV LAB
* @DATE    : 2019-01-23
* @BRIEF   : main function
* @UPDATE  : -
* @BRIEF   : -
***********************************************************/

#include "CamExposureControl.h"

int SetParam(INodeMap& nodeMap, gcstring name, bool val){
    CBooleanPtr pVal = nodeMap.GetNode(name);

    if(IsAvailable(pVal) && IsWritable(pVal)){
        cout << "Param " << name << " : " << pVal->ToString() << " -> ";
        pVal->SetValue(val);
        cout << pVal->ToString() << endl;

        return EXIT_SUCCESS;
    }else{
        cout << "Param " << name << " : " << pVal->ToString() << " (Not changed)" << endl;

        return EXIT_FAILURE;
    }
}

int SetParam(INodeMap& nodeMap, gcstring name, int64_t val){
    CIntegerPtr pVal = nodeMap.GetNode(name);

    if(IsAvailable(pVal) && IsWritable(pVal)){
        cout << "Param " << name << " : " << pVal->ToString() << " -> ";
        pVal->SetValue(val);
        cout << pVal->ToString() << endl;

        return EXIT_SUCCESS;
    }else{
        cout << "Param " << name << " : " << pVal->ToString() << " (Not changed)" << endl;

        return EXIT_FAILURE;
    }
}

int SetParam(INodeMap& nodeMap, gcstring name, double val){
    CFloatPtr pVal = nodeMap.GetNode(name);

    if(IsAvailable(pVal) && IsWritable(pVal)){
        cout << "Param " << name << " : " << pVal->ToString() << " -> ";
        pVal->SetValue(val);
        cout << pVal->ToString() << endl;

        return EXIT_SUCCESS;
    }else{
        cout << "Param " << name << " : " << pVal->ToString() << " (Not changed)" << endl;

        return EXIT_FAILURE;
    }
}

int SetParam(INodeMap& nodeMap, gcstring name, gcstring val){
    CEnumerationPtr pVal = nodeMap.GetNode(name);

    if(IsAvailable(pVal) && IsWritable(pVal)){
        CEnumEntryPtr pEntry = pVal->GetEntryByName(val);

        if(IsAvailable(pEntry) && IsReadable(pEntry)){
            int64_t vEntry = pEntry->GetValue();

            std::cout << "Param " << name << " : " << pVal->ToString() << " -> ";
            pVal->SetIntValue(vEntry);
            std::cout << pVal->ToString() << std::endl;

            return EXIT_SUCCESS;
        }else{
            std::cout << "Param " << name << " : " << pVal->ToString() << " (Not changed)" << std::endl;

            return EXIT_FAILURE;
        }
    }else{
        std::cout << "Param " << name << " : " << pVal->ToString() << " (Not changed)" << std::endl;

        return EXIT_FAILURE;
    }
}

int SetParam(INodeMap& nodeMap, const char* name, bool val){
    return SetParam(nodeMap, gcstring(name), val);
}

int SetParam(INodeMap& nodeMap, const char* name, int64_t val){
    return SetParam(nodeMap, gcstring(name), val);
}

int SetParam(INodeMap& nodeMap, const char* name, double val){
    return SetParam(nodeMap, gcstring(name), val);
}

int SetParam(INodeMap& nodeMap, const char* name, const char* val){
    return SetParam(nodeMap, gcstring(name), gcstring(val));
}

// Example entry point; please see Enumeration example for more in-depth 
// comments on preparing and cleaning up the system.
int main(int argc, char** argv)
{
        int result = 0;

        // Print application build information
        cout << "Application build date: " << __DATE__ << " " << __TIME__ << endl << endl;

        // Retrieve singleton reference to system object
        SystemPtr system = System::GetInstance();

        // Retrieve list of cameras from the system
        CameraList camList = system->GetCameras();

        unsigned int numCameras = camList.GetSize();

        cout << "Number of cameras detected: " << numCameras << endl << endl;

        // Finish if there are no cameras
        if (numCameras == 0)
        {
                // Clear camera list before releasing system
                camList.Clear();

                // Release system
                system->ReleaseInstance();

                cout << "Not enough cameras!" << endl;
                cout << "Done! Press Enter to exit..." << endl;
                getchar();

                return -1;
        }

	double GainToSet;
	double ExpToSet;
	if(argc > 2)
	{
	  GainToSet = atof(argv[1]);
	  ExpToSet = atof(argv[2]);
	} else
	{ 
	  GainToSet = 14.0f;
	  ExpToSet = 30000.0f;
	}

        cout << "Initial Gain : " << GainToSet << " Initial ExpT : " << ExpToSet << endl << endl;
        // AE camera Setup
        CameraPtr pAECam;
        pAECam = camList.GetByIndex(1);

        // Initialize camera
        pAECam->Init();
        pAECam->AcquisitionStop();

        // Retrieve GenICam nodemap
        INodeMap& nodeMap = pAECam->GetNodeMap();
        SetParam(nodeMap, "AcquisitionMode", "Continuous");

        // 1. Ensure trigger mode off
        if (pAECam->TriggerMode == NULL || pAECam->TriggerMode.GetAccessMode() != RW)
        {
                cout << "Unable to disable trigger mode. Aborting..." << endl;
                return -1;
        }
        pAECam->TriggerMode.SetValue(TriggerMode_Off);
        cout << "Trigger mode disabled..." << endl;

        // 2. Select trigger source
        if (pAECam->TriggerSource == NULL || pAECam->TriggerSource.GetAccessMode() != RW)
        {
                cout << "Unable to set trigger mode (node retrieval). Aborting..." << endl;
                return -1;
        }
        pAECam->TriggerSource.SetValue(TriggerSource_Software);
        cout << "Trigger source set to software..." << endl;
        // 3. Turn trigger mode on
        if (pAECam->TriggerMode == NULL || pAECam->TriggerMode.GetAccessMode() != RW)
        {
                cout << "Unable to disable trigger mode. Aborting..." << endl;
                return -1;
        }
        pAECam->TriggerMode.SetValue(TriggerMode_On);
        cout << "Trigger mode turned back on..." << endl << endl;

        SetParam(nodeMap, "ExposureAuto", "Continuous");
        SetParam(nodeMap, "AutoExposureTimeUpperLimit", 67000.0);
        SetParam(nodeMap, "GainAuto", "Continuous");
        SetParam(nodeMap, "PixelFormat", "RGB8");

        cout << "AE Camera Congifuration !! " << endl << endl;
        pAECam->BeginAcquisition();
        usleep(100);

        SetParam(nodeMap, "ExposureTime", ExpToSet);
        SetParam(nodeMap, "Gain", GainToSet);
        pAECam->TriggerSoftware.Execute();
        cout << "AE_Cam Wait for trigger..." << endl << endl;
        usleep(100);        
 
        // Run example on each camera
//        for (unsigned int i = 0; i < numCameras; i++)
        for (unsigned int i = 0; i < 1; i++)
        {
                cout << endl << "Running example for camera " << i << "..." << endl;
                //CAMERA * pCamAE = new CAMERA(camList.GetByIndex(i),5.0, 15000.0);
                CAMERA * pCamAE = new CAMERA(camList.GetByIndex(0),pAECam,GainToSet, ExpToSet);
                // TODO. if we want to run this system with multiple camera, we shuold change "for function" to multi thread...
                pCamAE->RunNoiseAwareExposureControl();

                cout << "Camera " << i << " example complete..." << endl << endl;
            	delete pCamAE;

        }

        pAECam->EndAcquisition();
        pAECam->DeInit();

        // Clear camera list before releasing system
        camList.Clear();

        // Release system
        system->ReleaseInstance();

        cout << endl << "Done! Press Enter to exit..." << endl;
        getchar();

        return result;
}


