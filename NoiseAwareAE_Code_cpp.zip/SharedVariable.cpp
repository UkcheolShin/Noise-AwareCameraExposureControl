#include "SharedVariable.h"

int FlagExpT_ = 0;
int FlagGain_ = 0;
