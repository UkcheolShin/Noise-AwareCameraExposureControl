/***********************************************************
* @PROJECT : Noise Aware Image Assessment metric based Auto Exposure Control
* @TITLE   : Camera CallBack Class
* @AUTHOR  : Uk Cheol Shin, KAIST RCV LAB
* @DATE    : 2018-08-14
* @BRIEF   : Calculate Entropy weighted gradient value
* @UPDATE  : 2019-01-23
* @BRIEF   : Update Control Part to use Nelder-Mead Algorithm.
***********************************************************/
#ifndef __CAMRA_CALLBACK_H__
#define __CAMRA_CALLBACK_H__

#include "Spinnaker.h"
#include "SpinGenApi/SpinnakerGenApi.h"
#include "SharedVariable.h"

#include <iostream>
#include <sstream>
#include <chrono>

#define DEBUG_CALL_BACK 0

using namespace Spinnaker;
using namespace Spinnaker::GenApi;
using namespace Spinnaker::GenICam;
using namespace std;

class CallBackExposureValue
{
private:
        const INodeMap & nodeMap_;
        int64_t callbackGain_;
        int64_t callbackExposureTime_;
        
        // @brief Configure Callbacks & Disable Auto Exposure Control
        int ConfigureCallbacks(const INodeMap & nodeMap, int64_t & callbackExposureTime, int64_t & callbackGain);
        // @brief Deregistering the callbacks and thuring automatic gain, exposure time, and white balance back on.
        int ResetCallbacks(const INodeMap & nodeMap, int64_t & callbackExposureTime, int64_t & callbackGain);
       
public:
        CallBackExposureValue(INodeMap & nodeMap);
        ~CallBackExposureValue();
        // @brief Change Exposure Time & Gain
        int ChangeGainAndExpTime(double gainToSet, double exptimeToSet);
        // @brief Change Exposure Time & Gain
        int ChangeGainAndExpTime();
};

#endif // define __CAMRA_CALLBACK_H__
