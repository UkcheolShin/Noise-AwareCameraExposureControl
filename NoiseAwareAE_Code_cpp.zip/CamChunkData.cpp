/***********************************************************
* @PROJECT : Noise Aware Image Assessment metric based Auto Exposure Control
* @TITLE   : Camera Chunk Data Class
* @AUTHOR  : Uk Cheol Shin, KAIST RCV LAB
* @DATE    : 2018-08-14
* @BRIEF   : Calculate Entropy weighted gradient value
* @UPDATE  : 2019-01-23
* @BRIEF   : Update Control Part to use Nelder-Mead Algorithm.
***********************************************************/

#include "CamChunkData.h"

CamChunkData::CamChunkData(INodeMap & nodeMap) : chosenChunkData(IMAGE)
{
        int result = 0;
        result = ConfigureChunkData(nodeMap);
        if(result != 0) throw -1;
}

CamChunkData::~CamChunkData()
{ }

int CamChunkData::ConfigureChunkData(INodeMap & nodeMap)
{
        int result = 0;

        cout << endl << endl << "*** CONFIGURING CHUNK DATA ***" << endl << endl;

        try
        {
                // 1. Activate chunk mode
                // Once enabled, chunk data will be available at the end of the payload
                // of every image captured until it is disabled. Chunk data can also be 
                // retrieved from the nodemap.
                CBooleanPtr ptrChunkModeActive = nodeMap.GetNode("ChunkModeActive");

                if (!IsAvailable(ptrChunkModeActive) || !IsWritable(ptrChunkModeActive))
                {
                        cout << "Unable to activate chunk mode. Aborting..." << endl << endl;
                        return -1;
                }

                ptrChunkModeActive->SetValue(true);

                cout << "Chunk mode activated..." << endl;

                // 2. Enable all types of chunk data
                // Enabling chunk data requires working with nodes: "ChunkSelector"
                // is an enumeration selector node and "ChunkEnable" is a boolean. It
                // requires retrieving the selector node (which is of enumeration node 
                // type), selecting the entry of the chunk data to be enabled, retrieving 
                // the corresponding boolean, and setting it to true. 
                //
                // In this example, all chunk data is enabled, so these steps are 
                // performed in a loop. Once this is complete, chunk mode still needs to
                // be activated.
                NodeList_t entries;

                // Retrieve the selector node
                CEnumerationPtr ptrChunkSelector = nodeMap.GetNode("ChunkSelector");

                if (!IsAvailable(ptrChunkSelector) || !IsReadable(ptrChunkSelector))
                {
                        cout << "Unable to retrieve chunk selector. Aborting..." << endl << endl;
                        return -1;
                }

                // Retrieve entries
                ptrChunkSelector->GetEntries(entries);

                cout << "Enabling entries..." << endl;

                for (int i = 0; i < entries.size(); i++)
                {
                        // Select entry to be enabled
                        CEnumEntryPtr ptrChunkSelectorEntry = entries.at(i);

                        // Go to next node if problem occurs
                        if (!IsAvailable(ptrChunkSelectorEntry) || !IsReadable(ptrChunkSelectorEntry))
                        {
                                continue;
                        }

                        ptrChunkSelector->SetIntValue(ptrChunkSelectorEntry->GetValue());

                        cout << "\t" << ptrChunkSelectorEntry->GetSymbolic() << ": ";

                        // Retrieve corresponding boolean
                        CBooleanPtr ptrChunkEnable = nodeMap.GetNode("ChunkEnable");

                        // Enable the boolean, thus enabling the corresponding chunk data
                        if (!IsAvailable(ptrChunkEnable))
                        {
                                cout << "Node not available" << endl;
                        }
                        else if (ptrChunkEnable->GetValue())
                        {
                                cout << "Enabled" << endl;
                        }
                        else if (IsWritable(ptrChunkEnable))
                        {
                                ptrChunkEnable->SetValue(true);
                                cout << "Enabled" << endl;
                        }
                        else
                        {
                                cout << "Node not writable" << endl;
                        }
                }
        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                result = -1;
        }

        return result;
}

// This function displays a select amount of chunk data from the image. Unlike
// accessing chunk data via the nodemap, there is no way to loop through all 
// available data.
int CamChunkData::DisplayChunkData(ImagePtr pImage)
{
        int result = 0;

        cout << "Printing chunk data from image..." << endl;

        try
        {
                //
                // Retrieve chunk data from image
                //
                // *** NOTES ***
                // When retrieving chunk data from an image, the data is stored in a
                // a ChunkData object and accessed with getter functions.
                //
                ChunkData chunkData = pImage->GetChunkData();
        
                //
                // Retrieve exposure time; exposure time recorded in microseconds
                //
                // *** NOTES ***
                // Floating point numbers are returned as a float64_t. This can safely
                // and easily be statically cast to a double.
                //
                double exposureTime = static_cast<double>(chunkData.GetExposureTime());
                std::cout << "\tExposure time: " << exposureTime << endl;

                //
                // Retrieve frame ID
                //
                // *** NOTES ***
                // Integers are returned as an int64_t. As this is the typical integer
                // data type used in the Spinnaker SDK, there is no need to cast it.
                //
                int64_t frameID = chunkData.GetFrameID();
                cout << "\tFrame ID: " << frameID << endl;

                // Retrieve gain; gain recorded in decibels
                double gain = chunkData.GetGain();
                cout << "\tGain: " << gain << endl;

                // Retrieve height; height recorded in pixels
                int64_t height = chunkData.GetHeight();
                cout << "\tHeight: " << height << endl;

                // Retrieve offset X; offset X recorded in pixels
                int64_t offsetX = chunkData.GetOffsetX();
                cout << "\tOffset X: " << offsetX << endl;

                // Retrieve offset Y; offset Y recorded in pixels
                int64_t offsetY = chunkData.GetOffsetY();
                cout << "\tOffset Y: " << offsetY << endl;

                // Retrieve sequencer set active
                int64_t sequencerSetActive = chunkData.GetSequencerSetActive();
                cout << "\tSequencer set active: " << sequencerSetActive << endl;

                // Retrieve timestamp
                int64_t timestamp = chunkData.GetTimestamp();
                cout << "\tTimestamp: " << timestamp << endl;

                // Retrieve width; width recorded in pixels
                int64_t width = chunkData.GetWidth();
                cout << "\tWidth: " << width << endl;
        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                result = -1;
        }
        
        return result;
}

// This function displays all available chunk data by looping through the chunk 
// data category node on the nodemap.
int CamChunkData::DisplayChunkData(INodeMap & nodeMap)
{
        int result = 0;

        cout << "Printing chunk data from nodemap..." << endl;

        try
        {
                //
                // Retrieve chunk data information nodes
                //
                // *** NOTES ***
                // As well as being written into the payload of the image, chunk data is
                // accessible on the GenICam nodemap. Insofar as chunk data is enabled,
                // it is available from both sources.
                //
                CCategoryPtr ptrChunkDataControl = nodeMap.GetNode("ChunkDataControl");
                if (!IsAvailable(ptrChunkDataControl) || !IsReadable(ptrChunkDataControl))
                {
                        cout << "Unable to retrieve chunk data control. Aborting..." << endl << endl;
                        return -1;
                }

                FeatureList_t features;
                ptrChunkDataControl->GetFeatures(features);

                // Iterate through children
                FeatureList_t::const_iterator it;

                for (it = features.begin(); it != features.end(); ++it)
                {
                        CNodePtr pFeature = (CNodePtr)*it;

                        cout << "\t" << pFeature->GetDisplayName() << ": ";

                        if (!IsAvailable(pFeature) || !IsReadable(pFeature))
                        {
                                cout << "node not available" << endl;
                                result = result | -1;
                                continue;
                        }
                        //
                        // Print boolean node type value
                        //
                        // *** NOTES ***
                        // Boolean information is manipulated to output the more-easily
                        // identifiable 'true' and 'false' as opposed to '1' and '0'.
                        //
                        else if (pFeature->GetPrincipalInterfaceType() == intfIBoolean)
                        {
                                CBooleanPtr pBool = (CBooleanPtr)pFeature;
                                bool value = pBool->GetValue();
                                cout << (value ? "true" : "false") << endl;
                        }
                        //
                        // Print non-boolean node type value
                        //
                        // *** NOTES ***
                        // All nodes can be cast as value nodes and have their information
                        // retrieved as a string using the ToString() method. This is much
                        // easier than dealing with each node type individually.
                        //
                        else
                        {
                                CValuePtr pValue = (CValuePtr)pFeature;
                                cout << pValue->ToString() << endl;
                        }
                }
        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                result = -1;
        }
        
        return result;
}
