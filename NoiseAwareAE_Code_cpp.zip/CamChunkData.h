/***********************************************************
* @PROJECT : Noise Aware Image Assessment metric based Auto Exposure Control
* @TITLE   : Camera Chunk Data Class
* @AUTHOR  : Uk Cheol Shin, KAIST RCV LAB
* @DATE    : 2018-08-14
* @BRIEF   : Calculate Entropy weighted gradient value
* @UPDATE  : 2019-01-23
* @BRIEF   : Update Control Part to use Nelder-Mead Algorithm.
***********************************************************/
#ifndef __CAMERA_CHUNK_DATA_H__
#define __CAMERA_CHUNK_DATA_H__

#include "Spinnaker.h"
#include "SpinGenApi/SpinnakerGenApi.h"
#include <iostream>
#include <sstream>
#include <chrono>

using namespace Spinnaker;
using namespace Spinnaker::GenApi;
using namespace Spinnaker::GenICam;
using namespace std;

class CamChunkData
{
private :

        // @brief ChunkData type
        // Use the following enum and global constant to select whether chunk data is 
        // displayed from the image or the nodemap.
        enum chunkDataType
        {
                IMAGE,
                NODEMAP
        };
        
        const chunkDataType chosenChunkData;
        
        int ConfigureChunkData(INodeMap & nodeMap);
public :
        CamChunkData(INodeMap & nodeMap);
        ~CamChunkData();
        int DisplayChunkData(ImagePtr pImage);
        int DisplayChunkData(INodeMap & nodeMap);
};


#endif // define __CAMERA_CHUNK_DATA_H__
