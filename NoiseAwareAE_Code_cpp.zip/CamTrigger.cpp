/***********************************************************
* @PROJECT : Noise Aware Image Assessment metric based Auto Exposure Control
* @TITLE   : Camera Trigger Configuration Class
* @AUTHOR  : Uk Cheol Shin, KAIST RCV LAB
* @DATE    : 2018-08-14
* @BRIEF   : Configure Camera Trigger option to use software trigger controlled by gain&exposure callback
* @UPDATE  : 2019-01-23
* @BRIEF   : Update Control Part to use Nelder-Mead Algorithm.
***********************************************************/

#include "CamTrigger.h"

Trigger::Trigger(CameraPtr pCam) : pCam_(pCam), chosenTrigger(SOFTWARE)
{
        int result = 0;
        result = ConfigureTrigger(pCam_);
        if(result != 0) throw -1;
}

Trigger::~Trigger()
{
        int result = 0;
        result = ResetTrigger(pCam_);
        if(result != 0) throw -1;
}

// @brief configure the camera to use a trigger
int Trigger::ConfigureTrigger(CameraPtr pCam)
{
        int result = 0;
        cout << endl << endl << "*** CONFIGURING TRIGGER ***" << endl << endl;
        try
        {
                if (chosenTrigger == SOFTWARE)
                {
                        cout << "Software trigger chosen..." << endl;
                }
                else
                {
                        cout << "Hardware trigger chosen..." << endl;
                }
                // 1. Ensure trigger mode off
                if (pCam->TriggerMode == NULL || pCam->TriggerMode.GetAccessMode() != RW)
                {
                        cout << "Unable to disable trigger mode. Aborting..." << endl;
                        return -1;
                }
                pCam->TriggerMode.SetValue(TriggerMode_Off);
                cout << "Trigger mode disabled..." << endl;

                // 2. Select trigger source
                if (chosenTrigger == SOFTWARE)
                {
                        // Set the trigger source to software
                        if (pCam->TriggerSource == NULL || pCam->TriggerSource.GetAccessMode() != RW)
                        {
                                cout << "Unable to set trigger mode (node retrieval). Aborting..." << endl;
                                return -1;
                        }
                        pCam->TriggerSource.SetValue(TriggerSource_Software);
                        cout << "Trigger source set to software..." << endl;
                }
                else
                {
                        // Set the trigger source to hardware (using 'Line0')
                        if (pCam->TriggerSource == NULL || pCam->TriggerSource.GetAccessMode() != RW)
                        {
                                cout << "Unable to set trigger mode (node retrieval). Aborting..." << endl;
                                return -1;
                        }
                        pCam->TriggerSource.SetValue(TriggerSource_Line0);
                        cout << "Trigger source set to hardware..." << endl;
                }

                // 3. Turn trigger mode on
                if (pCam->TriggerMode == NULL || pCam->TriggerMode.GetAccessMode() != RW)
                {
                        cout << "Unable to disable trigger mode. Aborting..." << endl;
                        return -1;
                }
                pCam->TriggerMode.SetValue(TriggerMode_On);
                cout << "Trigger mode turned back on..." << endl << endl;
        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                result = -1;
        }
        return result;
}

// @brief Retrieves a single image using the trigger.
// In this example, only a single image is captured and made available for acquisition 
// - as such, attempting to acquire two images for a single trigger execution would cause 
// the example to hang. This is different from other examples, whereby a 
// constant stream of images are being captured and made available for image
// acquisition.
int Trigger::GrabNextImageByTrigger(ImagePtr & pResultImage)
{
        int result = 0;
        try
        {
                // Use trigger to capture image

                // *** NOTES ***
                // The software trigger only feigns being executed by the Enter key;
                // what might not be immediately apparent is that there is no 
                // continuous stream of images being captured; in other examples that 
                // acquire images, the camera captures a continuous stream of images. 
                // When an image is then retrieved, it is plucked from the stream; 
                // there are many more images captured than retrieved. However, while 
                // trigger mode is activated, there is only a single image captured at 
                // the time that the trigger is activated. 
                if (chosenTrigger == SOFTWARE)
                {
                        // Get user input
                        while((FlagGain_ != 1) | (FlagExpT_ != 1))
                                std::cout<<"error!"<<std::endl;
                        //getchar();
                        // Execute software trigger
                        if (pCam_->TriggerSoftware == NULL || pCam_->TriggerSoftware.GetAccessMode() != WO)
                        {
                                cout << "Unable to execute trigger..." << endl;
                                return -1;
                        }
                        //cout << "take a trigger!!" << endl;
                        pCam_->TriggerSoftware.Execute();
                        

                }
                else
                {
                        cout << "Use the hardware to trigger image acquisition." << endl;
                }
                // Retrieve the next received image
                pResultImage = pCam_->GetNextImage();
                pCam_->TriggerSoftware.Execute();
                pResultImage = pCam_->GetNextImage();
                FlagGain_ = 0;
                FlagExpT_ = 0;
        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                result = -1;
        }
        return result;
}

// @brief Return the camera to a normal state by turning off trigger mode
int Trigger::ResetTrigger(CameraPtr pCam)
{
        int result = 0;
        try
        {
                // Turn trigger mode back off
                if (pCam->TriggerMode == NULL || pCam->TriggerMode.GetAccessMode() != RW)
                {
                        cout << "Unable to disable trigger mode. Aborting..." << endl;
                        return -1;
                }
                pCam->TriggerMode.SetValue(TriggerMode_Off);
                cout << "Trigger mode disabled..." << endl << endl;
        }
        catch (Spinnaker::Exception &e)
        {
                cout << "Error: " << e.what() << endl;
                result = -1;
        }
        return result;
}
