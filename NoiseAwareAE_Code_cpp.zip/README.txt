The C++ code "NoiseAwareAE_Code_cpp.zip" includes the c++ version of the proposed image quality assessment metric and the Nelder-Mead optimization based control algorithm. 
The implemented code is designed to operate on a Flir blackfly color camera in a moving scenario. (Refer the ppt material for the changed part!)
Therefore, the NM optimization part's implementation differs from the Matlab version. 
Also, this code is not well-organized and has dependencies on OpenCV, spinnaker, and boost library. 
The user needs to adjust the dependency for target hardware or selectively use image quality assessment metric C++ code or other C++ code.
